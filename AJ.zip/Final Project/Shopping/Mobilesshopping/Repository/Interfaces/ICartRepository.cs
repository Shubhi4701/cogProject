﻿using JewelleryStore.Entities.Dto.CartItemDto;
using JewelleryStore.Entities.Models;

namespace JewelleryStore.Repository.Interfaces
{
    public interface ICartRepository
    {
        void AddItemToUserCart( int productId, int quantity, string userEmail);
        List<CartItemDto> GetAllCartItemsForUser(string userEmail);
        void ClearUserCart(string userEmail);
        void RemoveItemFromCartById(int productId, string userEmail);
        
    }
}
