﻿using Microsoft.AspNetCore.Mvc;
using JewelleryStore.Entities.Dto.CategoryDto;
using JewelleryStore.Entities.Dto.OrdersDto;
using JewelleryStore.Entities.Dto.ProductDto;
using JewelleryStore.Entities.Dto.UserDto;
using JewelleryStore.Entities.Models;

namespace JewelleryStore.Repository.Interfaces
{
    public interface IUserRepository
    {

        Task<RegisterUserDto> Register(RegisterUserDto registeruserdto);

        Task<string> Login(LoginUserDto loginUserDto);

        Task<IEnumerable<ResponseProductDto>> GetAllProducts();
        Task<IEnumerable<ResponseProductDto>> GetProductsByCategory(int categoryId);
        Task<List<CategoryDto>> GetCategories();
        Task<IEnumerable<ResponseProductDto>> SearchByBrand(string brandName);
        Task<RegisterUserDto> UpdateUser(int Id, RegisterUserDto user);
        Task<string> CheckOut(string userEmail);
        Task<IEnumerable<OrderItemDto>> GetOrdersByUserId(string userEmail);


    }
}
