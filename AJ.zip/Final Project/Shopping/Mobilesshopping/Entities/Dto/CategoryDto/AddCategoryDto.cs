﻿namespace JewelleryStore.Entities.Dto.CategoryDto
{
    public class AddCategoryDto
    {
        public string CategoryName { get; set; }
    }
}
