﻿using JewelleryStore.Entities.Dto.ProductDto;

namespace JewelleryStore.Entities.Dto.CategoryDto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public List<ResponseProductDto> Products { get; set; }
    }
}
