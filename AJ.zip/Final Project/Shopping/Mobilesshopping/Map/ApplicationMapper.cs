﻿using AutoMapper;
using JewelleryStore.Entities.Dto.AdminDto;
using JewelleryStore.Entities.Dto.CartItemDto;
using JewelleryStore.Entities.Dto.CategoryDto;
using JewelleryStore.Entities.Dto.ProductDto;
using JewelleryStore.Entities.Dto.UserDto;
using JewelleryStore.Entities.Models;

namespace JewelleryStore.Map
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<User, RegisterUserDto>().ReverseMap();
            CreateMap<User, LoginUserDto>().ReverseMap();
            CreateMap<Admin, LoginAdminDto>().ReverseMap();
            CreateMap<Admin, RegisterAdminDto>().ReverseMap();
            CreateMap<Product, RequestProductDto>().ReverseMap();
            CreateMap<Product, ResponseProductDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<Category, AddCategoryDto>().ReverseMap();
            CreateMap<CartItem, CartItemDto>().ReverseMap();

        }


    }
}
